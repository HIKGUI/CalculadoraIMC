package com.example.calculadoraimc;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.button.MaterialButtonToggleGroup;

public class MainActivity extends AppCompatActivity {

    private EditText edAltura;
    private EditText edPeso;
    private Button btHomem;
    private Button btMulher;
    private TextView tvResultado;

    private Button btLimpar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);


        edAltura = findViewById(R.id.edAltura);
        edPeso = findViewById(R.id.edPeso);
        btHomem = findViewById(R.id.btHomem);
        btMulher = findViewById(R.id.btMulher);
        tvResultado = findViewById(R.id.tvResultado);
        btLimpar = findViewById(R.id.btLimpar);

        btHomem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double imc = calcularIMC();
                definirIMCHomem(imc);

            }


        });

        btMulher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double imc = calcularIMC();
                definirIMCMulher(imc);

            }


        });

        btLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double imc = calcularIMC();
                Limpar();

            }


        });

    }

    private void definirIMCMulher(double imc) {
        String mensagem = "";

        if(imc < 19.1){
            mensagem = "Abaixo do peso";
        }else if((imc >= 19.1) && (imc <25.8 )){
            mensagem = "No peso normal";
        }else if((imc >= 25.8) && (imc <27.3 )){
            mensagem = "Marginalmente acima do peso";
        }else if((imc >= 27.3) && (imc <=32.3)){
            mensagem = "Acima do peso ideal";
        }else{
            mensagem = "Obeso";
        }


        tvResultado.setText("O IMC é:" + imc + "\n" + mensagem);
    }

    private void definirIMCHomem(double imc) {
        String mensagem = "";

        if(imc < 20.7){
            mensagem = "Abaixo do peso";
        }else if((imc >= 20.7) && (imc <26.4 )){
            mensagem = "No peso normal";
        }else if((imc >= 26.4) && (imc <27.8 )){
            mensagem = "Marginalmente acima do peso";
        }else if((imc >= 27.8) && (imc <=31.1)){
            mensagem = "Acima do peso ideal";
        }else{
            mensagem = "Obeso";
        }


        tvResultado.setText("O IMC é:" + imc + "\n" + mensagem);
    }

    private double calcularIMC(){

        /*retornando texto do campo editText e
          convertendo em int (Integer.parseInt)*/

        int peso = Integer.parseInt(edPeso.getText().toString());
        double altura = Double.parseDouble(edAltura.getText().toString());
        double imc = peso / (altura * altura);
        return imc;
    }


    public void Limpar(){
        edPeso.setText("");
        edAltura.setText("");
        tvResultado.setText("");
    }








}